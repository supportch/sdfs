# 6. Board Reference

This section lists the boards that currently supports SAMD51 functions. The features and appropriate parameters for the various function calls are explained. The information presented here is only an overview of each board, intended to support software development using the SAMD51 APIs. For complete functional and operating details on each board, please refer to that board's user manual.

