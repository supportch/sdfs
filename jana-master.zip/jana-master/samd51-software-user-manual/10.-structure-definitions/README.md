# 10. Structure definitions

Here is the structure used

* [**DSCSAM\_ADSETTINGS**](dscsam_adsettings.md)\*\*\*\*

