# DSCSAM\_FreeBoard

This function releases the SPI driver handle and BUSY GPIO.

```c
BYTE DSCSAM_FreeBoard();
```

| Return Value |
| :--- |
| Error code or 0. |

