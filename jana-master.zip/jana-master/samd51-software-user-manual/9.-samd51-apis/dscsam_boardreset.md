# DSCSAM\_BoardReset

This function resets the SAM.

```c
BYTE DSCSAM_BoardReset();
```

| Return Value |
| :--- |
| Error code or 0. |

