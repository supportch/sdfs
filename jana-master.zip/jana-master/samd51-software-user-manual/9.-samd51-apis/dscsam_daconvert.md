# DSCSAM\_DAConvert

This function outputs a value to a single D/A channel.

```c
BYTE DSCSAM_DAConvert(BYTE Channel, unsigned int DACode);
```

{% tabs %}
{% tab title="Input Parameters" %}
| Name | Description |
| :--- | :--- |
| Channel | 0-1 |
| DACode | 0-4095 |
{% endtab %}
{% endtabs %}

| Return Value |
| :--- |
| Error code or 0. |

