# 2. General programming guidelines

#### \*\*\*\*[**2.1 Initialization and Exit Function Calls** ](2.1-initialization-and-exit-function-calls.md)\*\*\*\*

#### [2.2 Error Handling](2.2-error-handling.md)

