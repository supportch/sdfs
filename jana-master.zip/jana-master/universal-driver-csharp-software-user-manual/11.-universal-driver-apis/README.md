# 11. Universal Driver APIs

Here are the list of Universal Driver APIs

* [dscADAutoCal\(\) ](untitled.md)
* [dscADCalVerify\(\)](dscadcalverify.md)
* [dscADSample\(\) ](dscadsample.md)
* [dscADScan\(\) ](dscadscan.md)
* [dscADSetChannel\(\)](dscadsetchannel.md)
* [dscADSetSettings\(\) ](dscadsetsettings.md)
* [dscCounterRead\(\)](dsccounterread.md)
* [dscCounterSetRateSingle\(\) ](untitled-1.md)
* [dscDAAutoCal\(\) ](dscdaautocal.md)
* [dscDACalVerify\(\) ](dscdacalverify.md)
* [dscDAConvert\(\)](dscdaconvert.md)
* [dscDAConvertScan\(\) ](dscdaconvertscan.md)
* [dscDIOInputBit\(\)](dscdioinputbit.md)
* [dscDIOInputByte\(\)](dscdioinputbyte.md)
* [dscDIOOutputBit\(\)](dscdiooutputbit.md)
* [dscDIOOutputByte\(\)](dscdiooutputbyte.md)
* [dscDIOSetConfig\(\)](dscdiosetconfig.md)
* [dscGetEEPROM\(\)](dscgeteeprom.md)
* [dscGetReferenceVoltages\(\)](dscgetreferencevoltages.md)
* [dscLEDTest\(\)](dscledtest.md)
* [dscSetCalMux\(\)](dscsetcalmux.md)
* [dscSetReferenceVoltages\(\)](dscsetreferencevoltages.md)

