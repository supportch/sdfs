# 2. General programming guidelines

