# 12. Structure definitions

Here are the list of structures

* [DSCADSCAN](dscadscan.md)
* [DSCADSETTINGS](dscadsettings.md)
* [DSCAUTOCAL](dscautocal.md)
* [DSCCB](dsccb.md)
* [DSCCBP](dsccbp.md)
* [DSCCR](dsccr.md)
* [DSCDACALPARAMS](dscdacalparams.md)
* [DSCDACS](dscdacs.md)
* [ERRPARAMS](errparams.md)

