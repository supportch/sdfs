# 7. JNMM-4LP-XT Driver Application Usage Instructions

The following section details about how to use the JNMM-4LP-XT Driver applications and to confirm the output which may be obtained through the application.

### [7.1 DIO Description](7.1-dio-description.md)

### [7.2 JNMMCANLoopBack Description](7.2-jnmmcanloopback-description.md)

### [7.3 JNMMCANDemo description](7.3-jnmmcandemo-description.md)

### [7.4 JNMMRWFunction description](7.4-jnmmrwfunction-description.md)

