# 8. Interface Connector Details

### [8.1 Digital I/O – J4](8.1-digital-i-o-j4.md)

### [8.2 CAN\(J5, J6, J7, J8\)](8.2-can-j5-j6-j7-j8.md)

