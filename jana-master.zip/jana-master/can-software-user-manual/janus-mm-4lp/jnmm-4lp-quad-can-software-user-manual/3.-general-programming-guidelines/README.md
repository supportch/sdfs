# 3. General Programming Guidelines

### [3.1 Initialization and Exit Function Calls for Linux](3.1-initialization-and-exit-function-calls-for-linux.md)

### [3.2 Error Handling for Linux](3.2-error-handling-for-linux.md)

### [3.3 Initialization and Exit Function Calls for Windows](3.3-initialization-and-exit-function-calls-for-windows.md)

### [3.4 Error Handling for Windows](3.4-error-handling-for-windows.md)

