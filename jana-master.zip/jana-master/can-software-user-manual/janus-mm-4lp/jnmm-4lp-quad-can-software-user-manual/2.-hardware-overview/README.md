# 2. Hardware Overview

### [2.1 Description](2.1-description.md)

### [2.2 Specifications](2.2-specifications.md)

