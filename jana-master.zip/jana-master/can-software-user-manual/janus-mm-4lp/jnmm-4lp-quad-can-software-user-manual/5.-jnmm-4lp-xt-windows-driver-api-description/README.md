# 5. JNMM-4LP-XT Windows Driver API Description

### [5.1 JNMMCANConfig](5.1-jnmmcanconfig.md)

### [5.2 JNMMCANTX](5.2-jnmmcantx.md)

### [5.3 JNMMCANRX](5.3-jnmmcanrx.md)

### [5.4 JNMMCANBaseAddrInit](5.4-jnmmcanbaseaddrinit.md)

### [5.5 JNMMCANDIOAddrInit](5.5-jnmmcandioaddrinit.md)

### [5.6 JNMMGetFPGAVersion](5.6-jnmmgetfpgaversion.md)

### [5.7 JNMMGetBoardVersion](5.7-jnmmgetboardversion.md)

### [5.8 JNMMGPIOConfig](5.8-jnmmgpioconfig.md)

### [5.9 JNMMGPIORead](5.9-jnmmgpioread.md)

### [5.10 JNMMGPIOWrite](5.10-jnmmgpiowrite.md)

### [5.11 JNMMGPIOReadBit](5.11-jnmmgpioreadbit.md)

### [5.12 JNMMGPIOWriteBit](5.12-jnmmgpiowritebit.md)

