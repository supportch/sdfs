# 5.A Structure definitions

Here are the structures used.

* [CANCONFIG](canconfig.md)
* [CANMESSAGE](canmessage.md)

