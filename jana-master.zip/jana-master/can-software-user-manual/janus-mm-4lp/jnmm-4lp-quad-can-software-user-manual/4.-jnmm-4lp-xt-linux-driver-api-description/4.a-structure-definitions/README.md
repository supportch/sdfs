# 4.A Structure Definitions

Here are the structures used.

* [CANCONFIG](canconfig.md)
* [CANMESSAGE](canmessage.md)
* [can\_device\_stats](can_device_stats.md)

