# 4. JNMM-4LP-XT Linux Driver API Description

### [4.1 JNMMCANConfig](4.1-jnmmcanconfig.md)

### [4.2 JNMMCANTX](4.2-jnmmcantx.md)

### [4.3 JNMMCANRX](4.3-jnmmcanrx.md)

### [4.4 JNMMCANErrorStat](4.4-jnmmcanerrorstat.md)

### [4.5 JNMMCANRead](4.5-jnmmcanread.md)

### [4.6 JNMMCANWrite](4.6-jnmmcanwrite.md)

### [4.7 JNMMCANBaseAddrInit](4.7-jnmmcanbaseaddrinit.md)

### [4.8 JNMMCANDIOAddrInit](4.8-jnmmcandioaddrinit.md)

### [4.9 JNMMGetFPGAVersion](4.9-jnmmgetfpgaversion.md)

### [4.10 JNMMGetBoardVersion](4.10-jnmmgetboardversion.md)

### [4.11 JNMMGPIOConfig](4.11-jnmmgpioconfig.md)

### [4.12 JNMMGPIORead](4.12-jnmmgpioread.md)

### [4.13 JNMMGPIOWrite](4.13-jnmmgpiowrite.md)

### [4.14 JNMMGPIOReadBit](4.14-jnmmgpioreadbit.md)

### [4.15 JNMMGPIOWriteBit](4.15-jnmmgpiowritebit.md)

