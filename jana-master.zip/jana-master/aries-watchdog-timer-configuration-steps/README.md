# Aries Watchdog Timer Configuration Steps User Manual

## [1. Watchdog Timer Operation](1.-watchdog-timer-operation.md)

## [2. Watchdog Timer Register Map](2.-watchdog-timer-register-map.md)

## [3. Watchdog Timer Configuration Steps](3.-watchdog-timer-configuration-steps.md)

