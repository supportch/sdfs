# 2. General programming guidelines

#### \*\*\*\*[**2.1 ISA Initialization and Exit Function Calls**](2.1-isa-initialization-and-exit-function-calls.md) ****

#### [2.2 PCI Initialization and Exit Function Calls](untitled-1.md)

#### [2.3 Error Handling](2.3.-error-handling.md)

