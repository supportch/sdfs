# DSCAUTOCAL

Legacy reference to maintain backwards-compatibility; identical to DSCADCALPARAMS.

