# 15. Structure definitions

Here are the list of structures

* [DSCAACSTATUS](dscaacstatus.md) 
* [DSCADCALPARAMS](dscadcalparams.md) 
* [DSCADINTSTATUS](dscadintstatus-1.md)
* [DSCADSCAN](dscadscan-1.md) 
* \*\*\*\*[DSCADSETTINGS](dscadsettings.md)
* [DSCAIOINT](dscaioint.md)
* [DSCAUTOCAL](dscautocal.md)
* [DSCCB ](dsccb.md)
* [DSCCBP](dsccbp.md) 
* [DSCCR](dsccr.md) 
* [DSCDACALPARAMS ](dscdacalparams.md)
* [DSCDACS](dscdacs.md) 
* [DSCDASETTINGS](dscdasettings.md) 
* [DSCDIOINT](dscdioint.md) 
* [DSCFIFO ](dscfifo.md)
* [DSCPWM](dscpwm.md) 
* [DSCS](dscs.md) 
* [DSCSPECIALFUNC](dscspecialfunc.md) 
* [DSCUSERINT](dscuserint-1.md) 
* [DSCUSERINTFUNCTION](dscuserintfunction.md) 
* [DSCWATCHDOG](dscwatchdog.md) 
* [DSCWGCONFIG](dscwgconfig.md) 
* _\*\*\*\*_[ERRPARAMS](errparams.md)

 

