# dscWatchdogConfig

```c
BYTE dscWatchdogConfig(DSCB board, DSCWATCHDOG* watch)
```

This function configures watchdog timer for desired operation and it does not enables the watch timer, the function dscWatchDogEnable \(\) must be called to enable watch dog timer.

