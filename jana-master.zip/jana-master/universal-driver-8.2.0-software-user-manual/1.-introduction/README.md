# 1. Introduction

This user manual contains all essential information about the Universal Driver demo applications, programming guidelines and usage instructions. This manual also includes the Universal Driver API descriptions with usage examples. Refer [index](../13.-index/) section for supported boards.

